import { chromium } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import dotenv from 'dotenv';
import config from '../playwright.config';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const envPath = path.resolve(__dirname, '../.env');
console.log('Resolved .env path:', envPath);
if (!fs.existsSync(envPath)) {
  console.error('Error: .env file does not exist at the resolved path:', envPath);
  process.exit(1);
}

const envContents = fs.readFileSync(envPath, 'utf-8');
console.log('Contents of .env file:', envContents);
if (fs.existsSync('.env')) {
dotenv.config({ path: 'c:/Users/reach/playwright-dashboard/.env' });
}

// Log the DATABASE_URL for debugging
console.log('DATABASE_URL:', process.env.DATABASE_URL);
console.log('Manual DATABASE_URL:', process.env['DATABASE_URL']);
console.log('All environment variables:', process.env);

// AUTH_FILE is where the authenticated session will be saved
const AUTH_FILE = 'auth/auth.json';
// BASE_URL is the login page URL, defaulting to Mux dashboard login
const BASE_URL = (config.use?.baseURL as string) || 'https://dashboard.mux.com/login';
// MANUAL_VERIFICATION_WAIT is the maximum time to wait for manual Okta verification, in milliseconds
const MANUAL_VERIFICATION_WAIT = parseInt(process.env.MANUAL_VERIFICATION_WAIT || '300000', 10);

async function globalSetup() {
  console.log('Starting Global Setup: Okta Authentication...\n');

  // Check if auth/auth.json already exists
  if (fs.existsSync(AUTH_FILE)) {
    console.log('Session found at', AUTH_FILE);
    console.log('Skipping login - reusing existing session\n');
    return;
  }

  console.log('No existing session found');
  console.log('Launching browser for manual Okta verification...\n');

  // Launch browser in NON-HEADLESS mode so you can see and interact with it
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    // Step 1: Navigate to Mux dashboard login page
    console.log(`Navigating to ${BASE_URL}`);
    await page.goto(BASE_URL, { waitUntil: 'networkidle' });
    console.log('Dashboard login page loaded\n');

    // Step 2: Wait for manual credential entry and Okta verification
    console.log('Waiting for manual credential entry...');
    console.log('INSTRUCTIONS:');
    console.log('1. Enter your email and password on the login form');
    console.log('2. Click Login button');
    console.log('3. Complete Okta verification (email code, SMS, authenticator, etc.)');
    console.log('4. Wait until redirected to the dashboard main page');
    console.log(`Total timeout: ${MANUAL_VERIFICATION_WAIT / 1000 / 60} minutes\n`);

    // Step 3: Wait for successful authentication and redirect to dashboard
    // Once you complete login + Okta verification, you'll be redirected to the views page
    await page.waitForURL('**/views**', { timeout: MANUAL_VERIFICATION_WAIT });
    console.log('Authentication successful! Redirected to dashboard\n');

    // Step 4: Save authenticated session state to auth/auth.json
    console.log('Saving authenticated session...');
    const storageState = await context.storageState();
    
    // Ensure auth directory exists
    const authDir = path.dirname(AUTH_FILE);
    if (!fs.existsSync(authDir)) {
      fs.mkdirSync(authDir, { recursive: true });
    }

    // Write storage state to file
    fs.writeFileSync(AUTH_FILE, JSON.stringify(storageState, null, 2));
    console.log(`Session saved to ${AUTH_FILE}\n`);

    console.log('Global Setup Complete!');
    console.log('Next test runs will automatically reuse this session\n');

  } catch (error) {
    console.error('Authentication failed:', error);
    throw error;
  } finally {
    // Close browser
    await context.close();
    await browser.close();
  }
}

export default globalSetup;
