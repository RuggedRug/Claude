// utils/viewHelper.ts
import { Page } from '@playwright/test';

export async function extractAllViewIds(page: Page): Promise<string[]> {
  const viewIds = new Set<string>();

  while (true) {
    // ⏳ Wait for rows
    try {
      await page.waitForSelector('a[href*="/views/"]', { timeout: 15000 });
    } catch {
      console.warn('⚠️ Views table did not render');
      break;
    }

    // 🔹 Collect IDs from current page
    const links = await page.locator('a[href*="/views/"]').all();
    for (const link of links) {
      const href = await link.getAttribute('href');
      if (!href) continue;

      const match = href.match(/\/views\/([a-f0-9-]+)/);
      if (match) viewIds.add(match[1]);
    }

    // 🧠 Detect pagination "Next" button
    const nextButton = page.getByRole('button', { name: /next/i });

    if (!(await nextButton.isVisible())) {
      break;
    }

    if (await nextButton.isDisabled()) {
      break; // 🚫 no more pages
    }

    // 👉 Go to next page
    await nextButton.click();
    await page.waitForTimeout(2000); // allow data load
  }

  return [...viewIds];
}
