import { test, Page, expect, Locator } from '@playwright/test';
import {
  insertStartupTimeMetrics, insertSmoothnessMetrics, insertVideoQualityMetrics, insertDeviceDetails,
  insertClientDetails, insertPlayerDetails, insertOrganizationDetails, insertVideoMetadata, insertStreamDetails,
  insertViewDetails, insertPlaybackDetails, insertViewerDetails, insertNetworkDetails, insertGeographyDetails,
  insertCustomDetails, insertAdsMetrics,
  insertRenditionDetails,
  getFailedViews,
saveCheckpoint,
isViewAlreadyProcessed,
  markViewStatus,
} from '../utils/db';
import { extractSmoothnessMetrics, extractRenditionShiftFallback } from '../scripts/smoothnessMetrics.extractor';
import { extractStartupTimeMetrics } from '../scripts/startupTimeMetrics.extractor';
import { extractAllViewIds } from '../utils/viewHelper';
import { extractVideoQualityMetrics } from '../scripts/video_quality_metrics.extractor';
import { extractDeviceDetails } from '../scripts/deviceDetails_metrics.extractor';
import { extractClientDetails } from '../scripts/clientDetails_metrics.extractor';
import { extractPlayerDetails } from '../scripts/player_details_metrics.extractor';
import { extractOrganizationDetails } from '../scripts/organizationDetails_metrics.extractor';
import { extractVideoMetadata } from '../scripts/videoMetadata_metrics.extractor';
import { extractStreamDetails } from '../scripts/streamDetails_metrics.extractor';
import { extractViewDetails } from '../scripts/viewDetails_metrics.extractor';
import { extractPlaybackDetails } from '../scripts/playbackDetails_metrics.extractor';
import { extractViewerDetails } from '../scripts/viewerDetails_metrics.extractor';
import { extractNetworkDetails } from '../scripts/networkDetails_metrics.extractor';
import { extractGeographyDetails } from '../scripts/geography_metrics.extractor';
import { extractAdsMetrics } from '../scripts/ads_metrics.extractor';
import { extractCustomDetails } from '../scripts/custom_metrics.extractor';
import { extractRenditionDetails } from '../scripts/renditionDetails_metrics.extractor';
import { getCheckpoint } from '../utils/db';
/* =========================
   TEST
========================= */

//https://dashboard.mux.com/organizations/g4m6v6/environments/4l0u8v/views?filters[0]=viewer_user_id:USERID%3Abolt%3Ac6af37a1-ec93-4827-94a2-fa5306288913&timeframe[]=1766255400&timeframe[]=1766341800




test('test dummy', async ({ browser }) => {
  const context = await browser.newContext({
    storageState: 'auth/auth.json', // already logged in
  });

  const listPage = await context.newPage();

  // 1️ Open views list
  await listPage.goto(
    'https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views',
    { waitUntil: 'networkidle', timeout: 15000 }
  );

  await listPage.pause();
});


// test('Last 24 hours → extract startup metrics', async ({ browser }) => {
//   const context = await browser.newContext({
//     storageState: 'auth/auth.json', // already logged in
//   });

//   const listPage = await context.newPage();

//   // 1️ Open views list
//   await listPage.goto(
//     'https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views',
//     { waitUntil: 'networkidle' }
//   );

//   // 2️ Capture ALL view IDs (pagination)
//   const viewIds = await extractAllViewIds(listPage);

//   // 3️ Process each view
//   const detailPage = await context.newPage();

//   for (const viewId of viewIds) {
//     const detailUrl =
//       `https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views/${viewId}`;

//     console.log(`-> Processing view ${viewId}`);


//     try {
//       await listPage.goto(detailUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });

//       // Insert parent view row first
//       await insertView({ view_id: viewId, started_at: null, ended_at: null });

//       // Extract metrics with internal timeouts
//       const startupMetrics = await extractStartupTimeMetrics(listPage);
//       console.log('* Extracted startup:', startupMetrics);

//       // Save to DB
//       await insertStartupTimeMetrics({
//         view_id: viewId,     
//         startup_time_score: startupMetrics.startup_time_score,
//         video_startup_time: startupMetrics.video_startup_time,
//         content_startup_time: startupMetrics.content_startup_time,
//       });

//       const smoothnessMetrics = await extractSmoothnessMetrics(listPage, viewId);
//       console.log('* Smoothness:', smoothnessMetrics);

//       // 3️⃣ INSERT smoothness
//       await insertSmoothnessMetrics({
//         view_id: viewId,    
//         smoothness_score: smoothnessMetrics.smoothness_score,
//         rebuffer_frequency: smoothnessMetrics.rebuffer_frequency,
//         rebuffer_duration: smoothnessMetrics.rebuffer_duration,
//         rebuffer_count: smoothnessMetrics.rebuffer_count,
//         rendition_change_count: smoothnessMetrics.rendition_change_count,
//       });

//     } catch (err) {

//     }
//   }

//   await context.close();
// });

// test('7-day rolling → extract all view metrics until October', async ({ browser }) => {
//   const context = await browser.newContext({
//     storageState: 'auth/auth.json',
//   });

//   const listPage = await context.newPage();
//   const detailPage = await context.newPage();

//   await listPage.goto(
//     'https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views',
//     { waitUntil: 'networkidle' }
//   );

//  let end = new Date();
//   let start = subtractDays(end, 7);

//   const allViewIds = new Set<string>();

//   while (start > new Date(end.getFullYear(), 9, 1)) {
//     const startUnix = toUnixSeconds(start);
//     const endUnix = toUnixSeconds(end);

//     const url =
//       `https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views` +
//       `?timeframe[]=${startUnix}&timeframe[]=${endUnix}`;

//     console.log(`📆 ${start.toDateString()} → ${end.toDateString()}`);
//     await listPage.goto(url, { waitUntil: 'networkidle' });

//     const ids = await extractAllViewIds(listPage);
//     ids.forEach((id: string) => allViewIds.add(id));


//     end = start;
//     start = subtractDays(end, 7);
//   }

//   console.log(`✅ TOTAL VIEW IDS: ${allViewIds.size}`);

//     // 3️⃣ Process each view
//     for (const viewId of allViewIds) {
//       const detailUrl =
//         `https://dashboard.mux.com/organizations/g4m6v6/environments/2egnqv/views/${viewId}`;

//       try {
//         await detailPage.goto(detailUrl, {
//           waitUntil: 'domcontentloaded',
//           timeout: 15000,
//         });

//         // 🔁 YOUR EXISTING LOGIC (UNCHANGED)
//         await insertView({ view_id: viewId, started_at: null, ended_at: null });

//         // Extract metrics with internal timeouts
//       const startupMetrics = await extractStartupTimeMetrics(listPage);
//       console.log('* Extracted startup:', startupMetrics);

//       // Save to DB
//       await insertStartupTimeMetrics({
//         view_id: viewId,     
//         startup_time_score: startupMetrics.startup_time_score,
//         video_startup_time: startupMetrics.video_startup_time,
//         content_startup_time: startupMetrics.content_startup_time,
//       });

//       const smoothnessMetrics = await extractSmoothnessMetrics(listPage, viewId);
//       console.log('* Smoothness:', smoothnessMetrics);

//       // 3️⃣ INSERT smoothness
//       await insertSmoothnessMetrics({
//         view_id: viewId,    
//         smoothness_score: smoothnessMetrics.smoothness_score,
//         rebuffer_frequency: smoothnessMetrics.rebuffer_frequency,
//         rebuffer_duration: smoothnessMetrics.rebuffer_duration,
//         rebuffer_count: smoothnessMetrics.rebuffer_count,
//         rendition_change_count: smoothnessMetrics.rendition_change_count,
//       });
//       } catch (err) {
//         console.error(`❌ Failed view ${viewId}`, err);
//       }
//     }


//   await context.close();

// });

// test('7-day rolling extraction with DB save per window', async ({ browser }) => {
//   const context = await browser.newContext({



//     storageState: 'auth/auth.json',
//   });

//   const listPage = await context.newPage();
//   const detailPage =  listPage;
//   let end = new Date();                 // today
//   let start = subtractDays(end, 7);     // today - 7 days

//   while (!reachedOct1(start)) {
//     const startUnix = toUnixSeconds(start);
//     const endUnix = toUnixSeconds(end);

//    const USER_ID = 'USERID:bolt:c6af37a1-ec93-4827-94a2-fa5306288913';
//     const encodedUserId = encodeURIComponent(USER_ID);

//     const ENV_ID = '4l0u8v';
//     const ORG_ID = 'g4m6v6';

//     const viewsUrl =
//         `https://dashboard.mux.com/organizations/${ORG_ID}` +
//         `/environments/${ENV_ID}/views` +
//         `?filters[0]=viewer_user_id:${encodedUserId}` +
//         `&timeframe[]=${startUnix}` +
//         `&timeframe[]=${endUnix}`;

//     console.log(`📅 Processing window: ${start.toDateString()} → ${end.toDateString()}`);

//     // 1️⃣ Load views for this 7-day window
//     await listPage.goto(viewsUrl, { waitUntil: 'networkidle' });

//     // 2️⃣ Get ALL view IDs for this window
//     const viewIds = await extractAllViewIds(listPage);
//     console.log(`   🔹 Found ${viewIds.length} views`);

//     // 3️⃣ Process EACH view immediately
//     for (const viewId of viewIds) {
//       const detailUrl =
//         `https://dashboard.mux.com/organizations/g4m6v6/environments/4l0u8v/views/${viewId}`;

//       try {
//         console.log(` ➜ View ${viewId}`);

//         await detailPage.goto(detailUrl, {
//           waitUntil: 'domcontentloaded',
//           timeout: 15000,
//         });

//         // 🔁 YOUR EXISTING LOGIC (UNCHANGED)
//         await insertView({ view_id: viewId, started_at: null, ended_at: null });

//         // Extract metrics with internal timeouts
//       const startupMetrics = await extractStartupTimeMetrics(detailPage);

// if (!startupMetrics) {
//   console.warn(`⚠️ No startup metrics for view ${viewId}`);
// } else {
//   await insertStartupTimeMetrics({
//     view_id: viewId,
//     startup_time_score: startupMetrics.startup_time_score,
//     video_startup_time: startupMetrics.video_startup_time,
//     content_startup_time: startupMetrics.content_startup_time,
//   });
// }

//       const smoothnessMetrics = await extractSmoothnessMetrics(listPage, viewId);
//       console.log('* Smoothness:', smoothnessMetrics);

//       // 3️⃣ INSERT smoothness
//       await insertSmoothnessMetrics({
//         view_id: viewId,    
//         smoothness_score: smoothnessMetrics.smoothness_score,
//         rebuffer_frequency: smoothnessMetrics.rebuffer_frequency,
//         rebuffer_duration: smoothnessMetrics.rebuffer_duration,
//         rebuffer_count: smoothnessMetrics.rebuffer_count,
//         rendition_change_count: smoothnessMetrics.rendition_change_count,
//       });

//       } catch (err) {
//         console.error(`❌ Failed view ${viewId}`, err);
//       }
//     }

//     // 4️⃣ Move window backward by 7 days
//     end = start;
//     start = subtractDays(end, 7);
//   }

//   await context.close();
// });


/* ───────── HELPERS ───────── */

const USER_ID = 'USERID:bolt:c6af37a1-ec93-4827-94a2-fa5306288913';
const ORG_ID = 'g4m6v6';
const ENV_ID = '4l0u8v';
const OCT_1 = new Date(new Date().getFullYear(), 9, 1);

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function now() {
  return new Date();
}

function toUnix(d: Date) {
  return Math.floor(d.getTime() / 1000);
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function addDays(d: Date, days: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

/* ───────── CORE VIEW PROCESSOR ───────── */

async function processSingleView(page: Page, viewId: string) {
  if (await isViewAlreadyProcessed(viewId)) return;

  try {
    await markViewStatus(viewId, 'PROCESSING');

    await page.goto(
      `https://dashboard.mux.com/organizations/${ORG_ID}/environments/${ENV_ID}/views/${viewId}`,
      { timeout: 30000, waitUntil: 'domcontentloaded' }
    );

    await page.waitForSelector('div._VideoViewDetails_93g9a_30 h4', { timeout: 30000 });

    const view = await extractViewDetails(page, viewId);
    if (view) await insertViewDetails(view);

    const startup = await extractStartupTimeMetrics(page, viewId);
    if (startup) await insertStartupTimeMetrics(startup);

    const smooth = await extractSmoothnessMetrics(page, viewId);
    if (smooth) await insertSmoothnessMetrics(smooth);

    const vq = await extractVideoQualityMetrics(page, viewId);
    if (vq) await insertVideoQualityMetrics(vq);

    const device = await extractDeviceDetails(page, viewId);
    if (device) await insertDeviceDetails(device);

    const client = await extractClientDetails(page, viewId);
    if (client) await insertClientDetails(client);

    const player = await extractPlayerDetails(page, viewId);
    if (player) await insertPlayerDetails(player);

    const org = await extractOrganizationDetails(page, viewId);
    if (org) await insertOrganizationDetails(org);

    const meta = await extractVideoMetadata(page, viewId);
    if (meta) await insertVideoMetadata(meta);

    const stream = await extractStreamDetails(page, viewId);
    if (stream) await insertStreamDetails(stream);

    const playback = await extractPlaybackDetails(page, viewId);
    if (playback) await insertPlaybackDetails(playback);

    const viewer = await extractViewerDetails(page, viewId);
    if (viewer) await insertViewerDetails(viewer);

    const net = await extractNetworkDetails(page, viewId);
    if (net) await insertNetworkDetails(net);

    const geo = await extractGeographyDetails(page, viewId);
    if (geo) await insertGeographyDetails(geo);

    const ads = await extractAdsMetrics(page, viewId);
    if (ads) await insertAdsMetrics(ads);

    const custom = await extractCustomDetails(page, viewId);
    if (custom) await insertCustomDetails(custom);

    const rend = await extractRenditionDetails(page, viewId);
    if (rend) await insertRenditionDetails(rend);

    await markViewStatus(viewId, 'SUCCESS');
  } catch (e) {
    await markViewStatus(viewId, 'FAILED', String(e));
    console.error(`❌ View failed ${viewId}`);
  }
}

/* ───────── WINDOW PROCESSOR ───────── */

async function processWindow(listPage: Page, detailPage: Page, start: Date, end: Date) {
  let triedFallback = false;

  while (true) {
    const url =
      `https://dashboard.mux.com/organizations/${ORG_ID}/environments/${ENV_ID}/views` +
      `?filters[0]=viewer_user_id:${encodeURIComponent(USER_ID)}` +
      `&timeframe[]=${toUnix(start)}` +
      `&timeframe[]=${toUnix(end)}`;

    console.log(`📅 Window: ${start.toDateString()} → ${end.toDateString()}`);
    await listPage.goto(url, { timeout: 30000 });

    let viewIds: string[] = [];
    try {
      viewIds = await extractAllViewIds(listPage);
    } catch {}

    if (viewIds.length === 0 && !triedFallback) {
      triedFallback = true;
      console.warn('🔁 Day fallback');
      start = startOfDay(start);
      end = addDays(start, 1);
      continue;
    }

    for (const id of viewIds) {
      await processSingleView(detailPage, id);
    }
    break;
  }
}

/* ───────── MAIN TEST ───────── */

test('7-day rolling extraction with checkpoint resume (UI SAFE)', async ({ browser }) => {
  test.setTimeout(0);

  const context = await browser.newContext({ storageState: 'auth/auth.json' });
  const listPage = await context.newPage();
  const detailPage = await context.newPage();

  /* PHASE 1 – RETRY FAILED */
  const failed = await getFailedViews();
  console.log(`🔁 Retrying ${failed.length} failed views`);
  for (const id of failed) {
    await processSingleView(detailPage, id);
  }

  /* PHASE 2 – FORWARD (checkpoint → now) */
  let checkpoint = (await getCheckpoint()) ?? new Date();
  let forwardStart = startOfDay(checkpoint);
  let forwardEnd = addDays(forwardStart, 1);
  const now = new Date();

  while (forwardStart < now) {
    await processWindow(listPage, detailPage, forwardStart, forwardEnd);
    await saveCheckpoint(forwardEnd);
    forwardStart = forwardEnd;
    forwardEnd = addDays(forwardStart, 1);
  }

  /* PHASE 3 – BACKFILL (checkpoint → Oct 1) */
  let backEnd = startOfDay(checkpoint);
  let backStart = addDays(backEnd, -1);

  while (backStart >= OCT_1) {
    await processWindow(listPage, detailPage, backStart, backEnd);
    await saveCheckpoint(backStart);
    backEnd = backStart;
    backStart = addDays(backEnd, -1);
  }

  await context.close();
});


// test('7-day rolling extraction with checkpoint resume (UI SAFE)', async ({ browser }) => {
//   test.setTimeout(0);

//   const context = await browser.newContext({
//     storageState: 'auth/auth.json',
//   });

//   const listPage = await context.newPage();
//   const detailPage = await context.newPage();

//   const checkpoint = await getCheckpoint();

//   let end = checkpoint ?? new Date();
//   let start = subtractDays(end, 1);

//   console.log(
//     checkpoint
//       ? `▶ Resuming from checkpoint: ${end.toDateString()}`
//       : '▶ No checkpoint found, starting fresh'
//   );

//   const USER_ID = 'USERID:bolt:c6af37a1-ec93-4827-94a2-fa5306288913';
//   const encodedUserId = encodeURIComponent(USER_ID);

//   while (!reachedOct1(start)) {
//     const startUnix = toUnixSeconds(start);
//     const endUnix = toUnixSeconds(end);

//     const viewsUrl =
//       `https://dashboard.mux.com/organizations/g4m6v6/environments/4l0u8v/views` +
//       `?filters[0]=viewer_user_id:${encodedUserId}` +
//       `&timeframe[]=${startUnix}` +
//       `&timeframe[]=${endUnix}`;

//     console.log(`📅 Window: ${start.toDateString()} → ${end.toDateString()}`);

//     await listPage.goto(viewsUrl, { waitUntil: 'networkidle' });

//     // ⏳ CRITICAL: let UI hydrate
//     await listPage.waitForTimeout(4000);

//     const viewIds = await extractAllViewIds(listPage);
//     console.log(`🔹 Found ${viewIds.length} views`);

//     for (const viewId of viewIds) {
//       console.log(`➡️ View ${viewId}`);

//       try {
//         await detailPage.goto(
//           `https://dashboard.mux.com/organizations/g4m6v6/environments/4l0u8v/views/${viewId}`,
//           { waitUntil: 'domcontentloaded', timeout: 20000 }
//         );

//         // 🔑 MUST COME FIRST
//         await waitForViewPageReady(detailPage);


//         await insertViewDetails({
//           view_id: viewId,
//           started_at: null,
//           ended_at: null,
//           playing_time_seconds: null,
//           content_playing_time_seconds: null,
//           seeking_count: null,
//           seeking_duration_seconds: null,
//           exited_before_video_start: null,
//           view_has_ad: null,
//           video_startup_failure: null,
//           view_dropped: null,
//         });

//         const view = await extractViewDetails(detailPage, viewId);
//         if (view) await insertViewDetails(view);

//         const startup = await extractStartupTimeMetrics(detailPage, viewId);
//         if (startup) await insertStartupTimeMetrics(startup);

//         let smooth = await extractSmoothnessMetrics(detailPage, viewId);
//         if (
//           smooth &&
//           (smooth.rendition_upshift_count == null ||
//             smooth.rendition_downshift_count == null)
//         ) {
//           const fallback = await extractRenditionShiftFallback(detailPage);
//           smooth.rendition_upshift_count ??= fallback?.rendition_upshift_count ?? null;
//           smooth.rendition_downshift_count ??= fallback?.rendition_downshift_count ?? null;
//         }
//         if (smooth) await insertSmoothnessMetrics(smooth);

//         const video = await extractVideoQualityMetrics(detailPage, viewId);
//         if (video) await insertVideoQualityMetrics(video);

//         const device = await extractDeviceDetails(detailPage, viewId);
//         if (device) await insertDeviceDetails(device);

//         const client = await extractClientDetails(detailPage, viewId);
//         if (client) await insertClientDetails(client);

//         const player = await extractPlayerDetails(detailPage, viewId);
//         if (player) await insertPlayerDetails(player);

//         const org = await extractOrganizationDetails(detailPage, viewId);
//         if (org) await insertOrganizationDetails(org);

//         const meta = await extractVideoMetadata(detailPage, viewId);
//         if (meta) await insertVideoMetadata(meta);

//         const stream = await extractStreamDetails(detailPage, viewId);
//         if (stream) await insertStreamDetails(stream);

//         const playback = await extractPlaybackDetails(detailPage, viewId);
//         if (playback) await insertPlaybackDetails(playback);

//         const viewer = await extractViewerDetails(detailPage, viewId);
//         if (viewer) await insertViewerDetails(viewer);

//         const network = await extractNetworkDetails(detailPage, viewId);
//         if (network) await insertNetworkDetails(network);

//         const geo = await extractGeographyDetails(detailPage, viewId);
//         if (geo) await insertGeographyDetails(geo);

//         const ads = await extractAdsMetrics(detailPage, viewId);
//         if (ads) await insertAdsMetrics(ads);

//         const custom = await extractCustomDetails(detailPage, viewId);
//         if (custom) await insertCustomDetails(custom);

//         const rendition = await extractRenditionDetails(detailPage, viewId);
//         if (rendition) await insertRenditionDetails(rendition);
//       } catch (err) {
//         console.error(`❌ View failed ${viewId}`, err);
//       }
//     }

//     // ✅ SAVE CHECKPOINT ONLY AFTER DAY IS DONE
//     await saveCheckpoint(end);
//     console.log(`✅ Checkpoint saved at ${end.toDateString()}`);

//     end = start;
//     start = subtractDays(end, 1);
//   }

//   await context.close();
// });



