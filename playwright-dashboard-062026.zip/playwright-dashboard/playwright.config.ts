import { defineConfig } from '@playwright/test';
import * as fs from 'fs';

export default defineConfig({
  globalSetup: './auth/global-setup.ts',
  timeout: 900000, // 15 minute timeout for full extraction tests
  testDir: './tests', // Ensure the tests directory is specified
  testMatch: '**/*.spec.ts', // Match all .spec.ts files
  use: {
    baseURL: 'https://dashboard.mux.com/login',
    storageState: 'auth/auth.json',
    headless: true,
  },
});