import { Page } from '@playwright/test';

function parseNumber(raw: string | null): number | null {
  if (!raw) return null;

  const cleaned = raw
    .replace(/seconds?/gi, '')
    .replace(/seek(s)?/gi, '')
    .replace(/[a-zA-Z]/g, '')
    .trim();

  const value = Number(cleaned);
  return Number.isFinite(value) ? value : null;
}



export async function extractStartupTimeMetrics(
  page: Page,
  viewId: string
): Promise<StartupTimeMetrics | null> {

  const blocks = page.locator('div._VideoViewDetails_93g9a_30');

  const startupBlock = blocks.filter({
    has: page.locator('h4', { hasText: /Startup|Seek/i }),
  });

  if (!(await startupBlock.first().isVisible())) {
    console.warn(`⚠️ Startup / Seek block not found for ${viewId}`);
    return null;
  }

  const getValue = async (label: string): Promise<number | null> => {
    const row = startupBlock.locator('tr', {
      has: page.locator('th', { hasText: new RegExp(label, 'i') }),
    });

    if (!(await row.count())) return null;

    const raw = await row.locator('td div').first().textContent();
    return parseNumber(raw?.trim() ?? null);
  };

  return {
    view_id: viewId,

    // ───────── STARTUP ─────────
    startup_time_score: await getValue('Startup Time Score'),
    video_startup_time: await getValue('Video Startup Time'),
    content_startup_time: await getValue('Content Startup Time'),

    // ───────── PLAYER ─────────
    player_start_time: await getValue('Player Start Time'),

    // ───────── SEEK ─────────
    seek_latency_avg: await getValue('Seek Latency'),
    seek_count: await getValue('Seek Count'),
    seek_duration: await getValue('Seek Duration'),
  };
}

export interface StartupTimeMetrics {
  view_id: string;

  startup_time_score: number | null;
  video_startup_time: number | null;
  content_startup_time: number | null;

  player_start_time: number | null;

  seek_latency_avg: number | null;
  seek_count: number | null;
  seek_duration: number | null;
}
