import { Page } from '@playwright/test';
export interface CustomDetails {
    view_id: string;
  selected_stream: string | null;
  config_name: string | null;
  ad_strategy: string | null;
  experiment_strategy: string | null;
  video_codec: string | null;
  audio_codec: string | null;
  video_dynamic_range: string | null;
  player_index: number | null;
}


export async function extractCustomDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<CustomDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Custom' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Custom block not found');
    return null;
  }

  const getText = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const text = await row.locator('td div').first().textContent();
    return text?.trim() ?? null;
  };

  const getNumber = async (label: string): Promise<number | null> => {
    const text = await getText(label);
    if (!text) return null;

    const value = Number(text);
    return Number.isFinite(value) ? value : null;
  };

  return {
    view_id: viewId,
    selected_stream: await getText('Selected Stream'),
    config_name: await getText('Config Name'),
    ad_strategy: await getText('Ad Strategy'),
    experiment_strategy: await getText('Experiment Strategy'),
    video_codec: await getText('Video Codec'),
    audio_codec: await getText('Audio Codec'),
    video_dynamic_range: await getText('Video Dynamic Range'),
    player_index: await getNumber('Player Index'),
  };
}
