export interface ViewerDetails {
  view_id: string;
  viewer_id: string | null;

}
import { Page } from '@playwright/test';


export async function extractViewerDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<ViewerDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Viewer' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Viewer block not found');
    return null;
  }

  const row = block.locator('tr', {
    has: page.locator('th', { hasText: 'Viewer ID' }),
  });

  if (!(await row.count())) return null;

  // STRICT MODE SAFE → always pick first td div
  const raw = await row.locator('td div').first().textContent();
  const viewerId = raw?.trim() ?? null;

  return {
    view_id: viewId,
    viewer_id: viewerId,
  };
}
