export interface GeographyDetails {
    view_id: string;
  country: string | null;
  continent: string | null;
  city: string | null;
  region: string | null;
  latitude: number | null;
  longitude: number | null;
}
import { Page } from '@playwright/test';


export async function extractGeographyDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<GeographyDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Geography' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Geography block not found');
    return null;
  }

  const getText = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const text = await row.locator('td div').first().textContent();
    return text?.trim() ?? null;
  };

  const getNumber = async (label: string): Promise<number | null> => {
    const text = await getText(label);
    if (!text) return null;

    const value = Number(text);
    return Number.isFinite(value) ? value : null;
  };

  return {
    view_id: viewId,
    country: await getText('Country'),
    continent: await getText('Continent'),
    city: await getText('City'),
    region: await getText('Region / State'),
    latitude: await getNumber('Latitude'),
    longitude: await getNumber('Longitude'),
  };
}
