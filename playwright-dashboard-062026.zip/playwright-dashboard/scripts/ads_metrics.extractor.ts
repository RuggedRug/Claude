export interface AdsMetrics {
  view_id: string;

  ad_playing_time_seconds: number | null;

  preroll_requested: boolean | null;
  preroll_played: boolean | null;

  ad_attempts: number | null;
  ad_impressions: number | null;
  ad_breaks: number | null;

  ad_error_percentage: number | null;
  ad_breaks_with_error_percentage: number | null;
  ad_startup_error_percentage: number | null;

  ad_exits_before_start: number | null;
  ad_exits_before_start_percentage: number | null;
}
 
import { Page } from '@playwright/test';


function parseSeconds(text: string | null): number | null {
  if (!text) return null;
  const match = text.match(/([\d.]+)s/);
  return match ? Number(match[1]) : null;
}

function parsePercentage(text: string | null): number | null {
  if (!text) return null;
  return Number(text.replace('%', '').trim());
}

function parseBoolean(text: string | null): boolean | null {
  if (!text) return null;
  return text.toLowerCase() === 'true';
}

function parseInteger(text: string | null): number | null {
  if (!text) return null;
  const n = Number(text);
  return Number.isNaN(n) ? null : n;
}

export async function extractAdsMetrics(
  page: Page,
  viewId: string
): Promise<AdsMetrics | null> {
  const block = page.locator('div._VideoViewDetails_93g9a_30').filter({
    has: page.locator('h4', { hasText: 'Ads' }),
  });

  try {
    await block.first().waitFor({ timeout: 8000 });
  } catch {
    console.warn(`⚠️ Ads block not found for ${viewId}`);
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;
    return (await row.locator('td div').first().textContent())?.trim() ?? null;
  };

  return {
    view_id: viewId,

    ad_playing_time_seconds: parseSeconds(
      await getValue('Ad Playing Time')
    ),

    preroll_requested: parseBoolean(
      await getValue('Preroll Requested')
    ),
    preroll_played: parseBoolean(
      await getValue('Preroll Played')
    ),

    ad_attempts: parseInteger(
      await getValue('Ad Attempts')
    ),
    ad_impressions: parseInteger(
      await getValue('Ad Impressions')
    ),
    ad_breaks: parseInteger(
      await getValue('Ad Breaks')
    ),

    ad_error_percentage: parsePercentage(
      await getValue('Ad Error Percentage')
    ),
    ad_breaks_with_error_percentage: parsePercentage(
      await getValue('Ad Breaks with Error Percentage')
    ),
    ad_startup_error_percentage: parsePercentage(
      await getValue('Ad Startup Error Percentage')
    ),

    ad_exits_before_start: parseInteger(
      await getValue('Ad Exits Before Start')
    ),
    ad_exits_before_start_percentage: parsePercentage(
      await getValue('Ad Exits Before Start Percentage')
    ),
  };
}
