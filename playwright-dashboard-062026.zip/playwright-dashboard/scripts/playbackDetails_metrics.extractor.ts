export interface PlaybackDetails {
    view_id: string | null;
  remote_played: boolean | null;
  autoplay: boolean | null;
  preload: boolean | null;
  used_pip: boolean | null;
  used_captions: boolean | null;
  used_fullscreen: boolean | null;
  time_shift_enabled: boolean | null;
}

import { Page } from '@playwright/test';


export async function extractPlaybackDetails(
  page: Page,
  viewId: string,
  timeout = 5000
): Promise<PlaybackDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Playback' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Playback block not found');
    return null;
  }

  const getBoolean = async (label: string): Promise<boolean | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const cell = row.locator('td div').first();
    const raw = (await cell.textContent())?.trim().toLowerCase();

    if (raw === 'true') return true;
    if (raw === 'false') return false;
    return null;
  };

  return {
    view_id: viewId,
    remote_played: await getBoolean('Remote Played'),
    autoplay: await getBoolean('Autoplay'),
    preload: await getBoolean('Preload'),
    used_pip: await getBoolean('Used PiP'),
    used_captions: await getBoolean('Used Captions'),
    used_fullscreen: await getBoolean('Used Fullscreen'),
    time_shift_enabled: await getBoolean('Time Shift Enabled'),
  };
}
