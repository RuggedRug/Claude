export interface StreamDetails {
    view_id: string;
  video_stream_type: string | null;
  source_type: string | null;
  source_url: string | null;
  duration_seconds: number | null;
  encoding_variant: string | null;
  drm_type: string | null;
}

import { Page } from '@playwright/test';


export async function extractStreamDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<StreamDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Stream' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Stream block not found');
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const cell = row.locator('td div').first();
    const text = await cell.textContent();
    return text?.trim() ?? null;
  };

  const parseDurationToSeconds = (raw: string | null): number | null => {
    if (!raw) return null;

    // examples: "55m 2s", "1h 3m 10s"
    const h = /(\d+)h/.exec(raw)?.[1];
    const m = /(\d+)m/.exec(raw)?.[1];
    const s = /(\d+)s/.exec(raw)?.[1];

    return (
      (h ? Number(h) * 3600 : 0) +
      (m ? Number(m) * 60 : 0) +
      (s ? Number(s) : 0)
    );
  };

  return {
     view_id: viewId,
    video_stream_type: await getValue('Video Stream Type'),
    source_type: await getValue('Source Type'),
    source_url: await getValue('Source URL'),
    duration_seconds: parseDurationToSeconds(
      await getValue('Duration')
    ),
    encoding_variant: await getValue('Encoding Variant'),
    drm_type: await getValue('DRM Type'),
  };
}

