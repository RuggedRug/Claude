export interface VideoMetadata {
    view_id: string;
  video_title: string | null;
  video_series: string | null;
  video_id: string | null;
  content_type: string | null;
}

import { Page } from '@playwright/test';


export async function extractVideoMetadata(
  page: Page,
  viewId: string,
  timeout = 5000
): Promise<VideoMetadata | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Video Metadata' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Video Metadata block not found');
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const cells = row.locator('td div');
    if (!(await cells.count())) return null;

    const text = await cells.first().textContent();
    return text?.trim() ?? null;
  };

  return {
    view_id: viewId,
    video_title: await getValue('Video Title'),
    video_series: await getValue('Video Series'),
    video_id: await getValue('Video ID'),
    content_type: await getValue('Content Type'),
  };
}
