export interface RenditionDetails {
    view_id: string | null;
  initial_bitrate: number | null;
  initial_framerate: number | null;
  video_height: number | null;
  video_width: number | null;
  bitrate: number | null;
  framerate: number | null;
}
import { Page } from '@playwright/test';

export async function extractRenditionDetails(
  page: Page,
  viewId: string
): Promise<RenditionDetails | null> {
  const block = page.locator('div._VideoViewDetails_93g9a_30').filter({
    has: page.locator('h4', { hasText: 'Rendition Detail' }),
  });

  try {
    await block.first().waitFor({ timeout: 8000 });
  } catch {
    console.warn(`⚠️ Rendition block missing for ${viewId}`);
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    // 👇 first() avoids strict mode violations
    return (await row.locator('td div').first().textContent())?.trim() ?? null;
  };

  return {
    view_id: viewId,

    initial_bitrate: parseNumber(
      await getValue('Initial Bitrate')
    ),
    initial_framerate: parseNumber(
      await getValue('Initial Framerate')
    ),

    bitrate: parseNumber(
      await getValue('Bitrate')
    ),
    framerate: parseNumber(
      await getValue('Framerate')
    ),

    video_height: parseNumber(
      await getValue('Video Height')
    ),
    video_width: parseNumber(
      await getValue('Video Width')
    ),
  };
}


function parseNumber(text: string | null): number | null {
  if (!text) return null;

  const cleaned = text
    .replace('Mbps', '')
    .replace('kbps', '')
    .replace('bps', '')
    .trim();

  const num = Number(cleaned);
  return Number.isNaN(num) ? null : num;
}
