export interface OrganizationDetails {
    view_id: string;
  sub_property_id: string | null;
}

import { Page } from '@playwright/test';


export async function extractOrganizationDetails(
  page: Page,
  viewId: string,
  timeout = 5000
): Promise<OrganizationDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Organization' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Organization block not found');
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const cells = row.locator('td div');
    if (!(await cells.count())) return null;

    const text = await cells.first().textContent();
    return text?.trim() ?? null;
  };

  return {
    view_id: viewId,
    sub_property_id: await getValue('Sub Property ID'),
  };
}
