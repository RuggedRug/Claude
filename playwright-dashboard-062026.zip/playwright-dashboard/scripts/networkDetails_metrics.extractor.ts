export interface NetworkDetails {
    view_id: string;
  cdn: string | null;
  video_cdn_trace: string | null;
  asn: string | null;
  connection_type: string | null;
  source_hostname: string | null;
  view_session_id: string | null;
}

import { Page } from '@playwright/test';


export async function extractNetworkDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<NetworkDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Network' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Network block not found');
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    // STRICT MODE SAFE
    const text = await row.locator('td div').first().textContent();
    return text?.trim() ?? null;
  };

  return {
        view_id: viewId,
    cdn: await getValue('CDN'),
    video_cdn_trace: await getValue('Video CDN Trace'),
    asn: await getValue('ASN'),
    connection_type: await getValue('Connection Type'),
    source_hostname: await getValue('Source Hostname'),
    view_session_id: await getValue('View Session ID'),
  };
}
