import { Page } from '@playwright/test';
// async function getTableValue(page: Page, label: string): Promise<string | null> {
//   const row = page.locator('table tr', { hasText: label }).first();
//   if (await row.count() === 0) return null;

//   const value = await row.locator('td div').textContent();
//   return value?.trim() || null;
// }


// export async function extractSmoothnessMetrics(page: Page, viewId: string) {
//   // wait until Smoothness section is visible
//   await page.waitForSelector('h4:has-text("Smoothness Metrics")');
//   const smoothness_score_text = await getTableValue(page, 'Smoothness Score');
//   const rebufferFrequency = await getTableValue(page, 'Rebuffer Frequency');
//   const rebufferDuration = await getTableValue(page, 'Rebuffer Duration');
//   const rebufferCountText = await getTableValue(page, 'Rebuffer Count');
//   const renditionChangeCountText = await getTableValue(page, 'Rendition Change Count');

//   return {
//     view_id: viewId,
//     smoothness_score: smoothness_score_text, // Mux UI does not show score → keep null
//     rebuffer_frequency: rebufferFrequency,
//     rebuffer_duration: rebufferDuration,
//     rebuffer_count: rebufferCountText ? Number(rebufferCountText) : null,
//     rendition_change_count: renditionChangeCountText ? Number(renditionChangeCountText) : null,
//   };
// }

export async function extractSmoothnessMetrics(page: Page,viewId: string) : Promise<SmoothnessMetrics | null> {
  const block = page.locator('div._VideoViewDetails_93g9a_30').filter({
    has: page.locator('h4', { hasText: 'Smoothness' }),
  });

  try {
    await block.first().waitFor({ state: 'visible', timeout: 15000 });
  } catch {
    console.warn('⚠️ Smoothness block missing');
    return null;
  }

  const getNumber = async (label: string): Promise<number | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: new RegExp(label, 'i') }),
    });

    if (!(await row.count())) return null;

    const raw = (await row.locator('td div').textContent())?.trim();
    if (!raw) return null;

    const cleaned = raw
      .replace('%', '')
      .replace('rebuffer/min', '')
      .replace('Mbps', '')
      .replace('s', '')
      .replace(/[^\d.]/g, '');

    const value = Number(cleaned);
    return Number.isFinite(value) ? value : null;
  };

  return {
    view_id: viewId,
    smoothness_score: await getNumber('Smoothness Score'),
    rebuffer_frequency: await getNumber('Rebuffer Frequency'),
    rebuffer_duration: await getNumber('Rebuffer Duration'),
    rebuffer_count: await getNumber('Rebuffer Count'),

    rendition_change_count: await getNumber('Rendition Change Count'),

    // ⚠️ THESE MAY OR MAY NOT EXIST HERE
    rendition_upshift_count: await getNumber('Rendition Upshift Count'),
    rendition_downshift_count: await getNumber('Rendition Downshift Count'),
  };
}

export async function extractRenditionShiftFallback(page: Page) {
  const block = page.locator('div._VideoViewDetails_93g9a_30').filter({
    has: page.locator('h4', { hasText: 'Video Quality Metrics' }),
  });

  try {
    await block.first().waitFor({ state: 'visible', timeout: 8000 });
  } catch {
    return null;
  }

  const getInt = async (label: string): Promise<number | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: new RegExp(label, 'i') }),
    });

    if (!(await row.count())) return null;

    const raw = (await row.locator('td div').textContent())?.trim();
    return raw ? Number(raw.replace(/[^\d]/g, '')) : null;
  };

  return {
    rendition_upshift_count: await getInt('Upshift'),
    rendition_downshift_count: await getInt('Downshift'),
  };
}


/** Convert UI text → number safely */
function toNumber(value: string | null): number | null {
  if (!value) return null;
  const cleaned = value.replace(/[^\d.]/g, '');
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

export interface SmoothnessMetrics {
  view_id: string;
  smoothness_score: number | null;
  rebuffer_frequency: number | null;
  rebuffer_duration: number | null;
  rebuffer_count: number | null;
  rendition_change_count: number | null;
  rendition_upshift_count: number | null;
  rendition_downshift_count: number | null;
}