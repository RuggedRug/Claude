import { Page } from '@playwright/test';

export interface DeviceDetails {
  view_id: string;
  device_name: string | null;
  device_model: string | null;
  device_category: string | null;
  device_brand: string | null;
  full_user_agent: string | null;
}

export async function extractDeviceDetails(
  page: Page,
  viewId: string
): Promise<DeviceDetails | null> {
  const blocks = page.locator('div._VideoViewDetails_93g9a_30');

  const deviceBlock = blocks.filter({
    has: page.locator('h4', { hasText: 'Device' }),
  });

  try {
    await deviceBlock.first().waitFor({ timeout: 5000 });
  } catch {
    console.warn(`⚠️ Device block missing for ${viewId}`);
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = deviceBlock.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const text = await row.locator('td div').textContent();
    return text?.trim() ?? null;
  };

  return {
    view_id: viewId,
    device_name: await getValue('Device Name'),
    device_model: await getValue('Device Model'),
    device_category: await getValue('Device Category'),
    device_brand: await getValue('Device Brand'),
    full_user_agent: await getValue('Full User Agent'),
  };
}
