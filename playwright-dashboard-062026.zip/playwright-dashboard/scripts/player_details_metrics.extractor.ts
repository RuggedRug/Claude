import { Page } from '@playwright/test';
export interface PlayerDetails {
    view_id: string;
  player_name: string | null;
  player_version: string | null;
  player_instance_id: string | null;
  player_language: string | null;

  software_name: string | null;
  software_version: string | null;

  player_height: number | null;
  player_width: number | null;

  mux_plugin: string | null;
  mux_plugin_version: string | null;
}


export async function extractPlayerDetails(
  page: Page,
  viewId: string,
  timeout = 5000
): Promise<PlayerDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Player' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Player block not found');
    return null;
  }

  const getValues = async (label: string): Promise<string[]> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return [];

    const values = row.locator('td div');
    const count = await values.count();

    const result: string[] = [];
    for (let i = 0; i < count; i++) {
      const text = await values.nth(i).textContent();
      if (text) result.push(text.trim());
    }

    return result;
  };

  const parseIntSafe = (v?: string): number | null => {
    if (!v) return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const playerValues = await getValues('Player Name');
  const playerVersion = await getValues('Player Version');

  return {
    view_id: viewId,
    player_name: playerValues[0] ?? null,
    player_version: playerVersion[0] ?? null,
    player_instance_id: (await getValues('Player Instance ID'))[0] ?? null,
    player_language: (await getValues('Player Language'))[0] ?? null,

    software_name: (await getValues('Software Name'))[0] ?? null,
    software_version: (await getValues('Software Version'))[0] ?? null,

    player_height: parseIntSafe((await getValues('Player Height'))[0]),
    player_width: parseIntSafe((await getValues('Player Width'))[0]),

    mux_plugin: (await getValues('Mux Plugin'))[0] ?? null,
    mux_plugin_version: (await getValues('Mux Plugin Version'))[0] ?? null,
  };
}