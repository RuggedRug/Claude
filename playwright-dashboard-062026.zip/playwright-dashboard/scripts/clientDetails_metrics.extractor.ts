export interface ClientDetails {
  view_id: string;
  browser: string | null;
  browser_version: string | null;
  os: string | null;
  os_version: string | null;
  page_type: string | null;
}
import { Page } from '@playwright/test';

export async function extractClientDetails(
  page: Page,
  viewId: string,
  timeout = 5000
): Promise<ClientDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'Client' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ Client block not found');
    return null;
  }

  const getValues = async (label: string): Promise<string[]> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return [];

    const cells = row.locator('td div');
    const count = await cells.count();

    const values: string[] = [];
    for (let i = 0; i < count; i++) {
      const text = await cells.nth(i).textContent();
      if (text) values.push(text.trim());
    }

    return values;
  };

  const browserValues = await getValues('Browser');

  return {
    view_id: viewId,
    browser: browserValues[0] ?? null,
    browser_version: browserValues[1] ?? null,
    os: (await getValues('OS'))[0] ?? null,
    os_version: (await getValues('OS Version'))[0] ?? null,
    page_type: (await getValues('Page Type'))[0] ?? null,
  };
}