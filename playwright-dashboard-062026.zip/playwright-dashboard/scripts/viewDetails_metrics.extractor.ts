export interface ViewDetails {
  view_id: string | null;
  started_at: string | null;          // ISO string
  ended_at: string | null;            // ISO string
  playing_time_seconds: number | null;
  content_playing_time_seconds: number | null;
  seeking_count: number | null;
  seeking_duration_seconds: number | null;
  exited_before_video_start: boolean | null;
  view_has_ad: boolean | null;
  video_startup_failure: boolean | null;
  view_dropped: boolean | null;
}
import { Page } from '@playwright/test';

export async function extractViewDetails(
  page: Page,
    viewId: string,
  timeout = 5000
): Promise<ViewDetails | null> {
  const block = page
    .locator('div._VideoViewDetails_93g9a_30')
    .filter({ has: page.locator('h4', { hasText: 'View' }) });

  try {
    await block.first().waitFor({ timeout });
  } catch {
    console.warn('⚠️ View block not found');
    return null;
  }

  const getValue = async (label: string): Promise<string | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: label }),
    });

    if (!(await row.count())) return null;

    const cell = row.locator('td div').first();
    const text = await cell.textContent();
    return text?.trim() ?? null;
  };

  const parseDuration = (raw: string | null): number | null => {
    if (!raw) return null;

    const m = /(\d+)m/.exec(raw)?.[1];
    const s = /(\d+)s/.exec(raw)?.[1];

    return (m ? Number(m) * 60 : 0) + (s ? Number(s) : 0);
  };

  const parseSeeking = (
    raw: string | null
  ): { count: number | null; duration: number | null } => {
    if (!raw) return { count: null, duration: null };

    // "1 seek for 1.3s seconds"
    const count = /(\d+)\s+seek/.exec(raw)?.[1];
    const duration = /([\d.]+)s/.exec(raw)?.[1];

    return {
      count: count ? Number(count) : null,
      duration: duration ? Number(duration) : null,
    };
  };

  const parseBoolean = (raw: string | null): boolean | null => {
    if (raw === null) return null;
    return raw.toLowerCase() === 'true';
  };

  const seekingRaw = await getValue('Seeking');
  const seeking = parseSeeking(seekingRaw);

  return {
    view_id: await getValue('View ID'),
    started_at: await getValue('Started at'),
    ended_at: await getValue('Ended at'),
    playing_time_seconds: parseDuration(await getValue('Playing Time')),
    content_playing_time_seconds: parseDuration(
      await getValue('Content Playing Time')
    ),
    seeking_count: seeking.count,
    seeking_duration_seconds: seeking.duration,
    exited_before_video_start: parseBoolean(
      await getValue('Exited Before Video Start')
    ),
    view_has_ad: parseBoolean(await getValue('View Has Ad')),
    video_startup_failure: parseBoolean(
      await getValue('Video Startup Failure')
    ),
    view_dropped: parseBoolean(await getValue('View Dropped')),
  };
}
