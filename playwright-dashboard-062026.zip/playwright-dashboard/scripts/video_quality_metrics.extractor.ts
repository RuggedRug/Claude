import { Page } from '@playwright/test';


export async function extractVideoQualityMetrics(page: Page,
  viewId: string) : Promise<VideoQualityMetrics   | null> {
  const block = page.locator('div._VideoViewDetails_93g9a_30').filter({
    has: page.locator('h4', { hasText: 'Video Quality Metrics' }),
  });

  try {
    await block.first().waitFor({ state: 'visible', timeout: 15000 });
  } catch {
    console.warn('⚠️ Video Quality Metrics block missing');
    return null;
  }

  const getNumber = async (label: string): Promise<number | null> => {
    const row = block.locator('tr', {
      has: page.locator('th', { hasText: new RegExp(label, 'i') }),
    });

    // 1️⃣ row may not exist
    if ((await row.count()) === 0) return null;

    const valueCell = row.locator('td div').first();

    // 2️⃣ wait for td to attach (NOT visible)
    try {
      await valueCell.waitFor({ state: 'attached', timeout: 3000 });
    } catch {
      return null;
    }

    // 3️⃣ read text safely
    const raw = (await valueCell.textContent())?.trim();
    if (!raw) return null;

    // 4️⃣ normalize
    const cleaned = raw
      .replace('%', '')
      .replace('Mbps', '')
      .replace('s', '')
      .replace(/[^\d.]/g, '');

    const value = Number(cleaned);
    return Number.isFinite(value) ? value : null;
  };

  return {
     view_id: viewId,
    video_quality_score: await getNumber('Video Quality Score'),
    upscale_percentage: await getNumber('Upscale Percentage'),
    downscale_percentage: await getNumber('Downscale Percentage'),
    max_upscale_percentage: await getNumber('Max Upscale Percentage'),
    max_downscale_percentage: await getNumber('Max Downscale Percentage'),
    weighted_average_bitrate: await getNumber('Weighted Average Bitrate'),
    request_throughput: await getNumber('Request Throughput'),
    request_latency: await getNumber('Request Latency'),
    max_request_latency: await getNumber('Max Request Latency'),
  };
}

export interface VideoQualityMetrics {
  view_id: string;
  video_quality_score: number | null;
  upscale_percentage: number | null;
  downscale_percentage: number | null;
  max_upscale_percentage: number | null;
  max_downscale_percentage: number | null;
  weighted_average_bitrate: number | null;
  request_throughput: number | null;
  request_latency: number | null;
  max_request_latency: number | null;
}